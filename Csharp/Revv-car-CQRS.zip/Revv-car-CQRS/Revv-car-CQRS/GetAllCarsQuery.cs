﻿internal class GetAllCarsQuery
{
}